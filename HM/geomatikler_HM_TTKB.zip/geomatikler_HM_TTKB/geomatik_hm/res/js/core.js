let canvas = document.getElementById('canvas')
canvas.style.cursor = 'pointer'
ctx = canvas.getContext('2d')

let clientWidth
let clientHeight
const w = 6
const h = 3
const clearSound = new Audio("sound/clear.mp3")
let lenX
let lenY
let stepx
let stepy
let steppx
let steppy
let sec = 1
let activeColor = 'black'
let activeObject = 'choice'
let activeElementID = null
let lineDrawing = false
let lineA, lineB
let myTime, time = 0
let delPointCount = 0

changeVariables = function () {
	clientWidth = innerWidth
	clientHeight = innerHeight
	canvas.width = clientWidth
	canvas.height = clientHeight
	_ORIGIN = { x: clientWidth / 2, y: clientHeight / 2 }
	if (innerHeight < innerWidth) {
		changeCSS("styleVertical.css")
		lenX = w
		lenY = h
	} else {
		changeCSS("styleHorizontal.css")
		lenX = h
		lenY = w
	}
	stepx = clientWidth / (2 * lenX)
	stepy = clientHeight / (2 * lenY)
}

changeVariables()

let arrObjects = []
let undoObjects = []
class mPoint {
	constructor(xpoint, ypoint) {
		let n = ""
		let s = 0
		arrObjects.forEach(item => {
			if (item.type == 'point') s++
		})
		s = s + delPointCount
		if (0 <= s && s < 14) {
			n = String.fromCharCode(s + 65)
		} else if (14 <= s && s < 25) {
			n = String.fromCharCode(s + 66)
		} else {
			n = "A" + (s - 24).toString()
		}

		this.name = n
		this.id = arrObjects.length
		this.xpoint = xpoint
		this.ypoint = -ypoint
		this.color = activeColor
		this.type = 'point'
	}
}
class mLine {
	constructor(a, b) {
		let s = 0
		arrObjects.forEach(item => {
			if (item.type == 'line') s++
		})
		this.name = 'y' + s
		if (s == 0) {
			this.name = 'y'
		}
		this.id = arrObjects.length
		this.a = a
		this.b = b

		if (Math.sign(b) == -1) {
			this.graph = a + '*x-' + Math.abs(b)
		} else {
			this.graph = a + '*x+' + b
		}

		this.color = activeColor
		this.type = 'line'
	}
}

drawCoordinates = function () {
	ctx.strokeStyle = ctx.fillStyle = 'white'
	ctx.fillRect(0, 0, clientWidth, clientHeight)

	steppx = (clientWidth / (2 * lenX)) / sec
	steppy = (clientHeight / (2 * lenY)) / sec

	/* Draw X axis */
	for (let i = -lenX; i <= lenX; i++) {
		let step = (clientWidth / (2 * lenX)) * (i + lenX)
		ctx.strokeStyle = ctx.fillStyle = 'black'
		ctx.beginPath()
		ctx.lineWidth = 0.3
		if (i == 0) ctx.lineWidth = 2
		ctx.moveTo(step, 0)
		ctx.lineTo(step, clientHeight)
		text(step - 15, _ORIGIN.y + 15, 'black', 'center', '15px arial', i * sec)
		ctx.stroke()
		ctx.closePath()
	}

	/* Draw Y axis */
	for (let i = -lenY; i <= lenY; i++) {
		let step = (clientHeight / (2 * lenY)) * (i + lenY)
		ctx.strokeStyle = ctx.fillStyle = 'black'
		ctx.beginPath()
		ctx.lineWidth = 0.3
		if (i == 0) ctx.lineWidth = 2
		ctx.moveTo(0, step)
		ctx.lineTo(clientWidth, step)
		if (i != 0) { text(_ORIGIN.x + 15, step + 15, 'black', 'center', '15px arial', -i * sec) }
		ctx.stroke()
		ctx.closePath()
	}

	/* Draw Origin */
	ctx.beginPath()
	ctx.strokeStyle = ctx.fill.style = 'black'
	ctx.arc(_ORIGIN.x, _ORIGIN.y, 2, 0, 2 * Math.PI)
	ctx.lineWidth = 5
	//text(_ORIGIN.x + 15, _ORIGIN.y - 10, 'black', 'center', 'bold 15px arial', 'O')
	ctx.stroke()
	ctx.fill()
	ctx.closePath()

	/* Add Entry & Draw Objects */
	objectsContainer.innerHTML = null

	let label = document.createElement('label')
	let input = document.createElement('input')

	input.id = -1
	label.htmlFor = input.id
	input.placeholder = 'Giriş'
	input.title = 'Giriş'

	input.setAttribute("onclick", "inputClick(event,id)")
	input.setAttribute("onkeydown", "inputKeyDown(event,id)")

	label.appendChild(input)
	objectsContainer.appendChild(label)


	arrObjects.sort(function (a, b) { return a.id - b.id });



	arrObjects.findLast((item) => {
		if (item.type === 'point') {
			drawPoint(item)
		} else {
			drawLine(item)
		}
	})

	if (activeElementID != null) {
		document.getElementById(activeElementID).style.background = 'lightgreen'
	}
}

function drawPoint(point) {
	ctx.beginPath()
	ctx.strokeStyle = ctx.fill.style = point.color
	ctx.arc(point.xpoint * steppx + _ORIGIN.x, point.ypoint * steppy + _ORIGIN.y, 2, 0, 2 * Math.PI)
	ctx.lineWidth = 5
	ctx.fillStyle = "white"
	ctx.fillRect(point.xpoint * steppx + _ORIGIN.x + 5, point.ypoint * steppy + _ORIGIN.y - 25, 20, 20)
	text(point.xpoint * steppx + _ORIGIN.x + 15, point.ypoint * steppy + _ORIGIN.y - 10, point.color, 'center', 'bold 15px arial', point.name)
	ctx.stroke()
	ctx.fill()
	ctx.closePath()

	labelCreator(point)
}
function drawLine(line) {
	let x, y
	ctx.strokeStyle = ctx.fill.style = line.color
	ctx.beginPath()
	ctx.lineWidth = 2
	x = -lenX * sec
	y = eval(line.graph) * (-stepy / sec) + _ORIGIN.y
	ctx.moveTo(x * stepx / sec + _ORIGIN.x, y)

	x = lenX * sec
	y = eval(line.graph) * (-stepy / sec) + _ORIGIN.y
	ctx.lineTo(x * stepx / sec + _ORIGIN.x, y)
	/* 	ctx.fillStyle = "white"
		ctx.fillRect(((lenY * sec - line.b) / line.a) * stepx / sec + _ORIGIN.x - 30, 15, 20, 20)
		text(((lenY * sec - line.b) / line.a) * stepx / sec + _ORIGIN.x - 20, 30, line.color, 'center', 'bold 15px arial', line.name) */
	ctx.stroke()
	ctx.fill()
	ctx.closePath()
	labelCreator(line)
}

function labelCreator(item) {
	let label = document.createElement('label')
	let input = document.createElement('input')
	let button = document.createElement('button')
	input.id = arrObjects.length - objectsContainer.childNodes.length

	label.htmlFor = input.id

	if (item.type == 'line') {
		let inval = 'y=' + item.graph
		inval = inval.replace('*', '')
		inval = inval.replace('+-', '-')
		if (item.a == 1 || item.a == -1) inval = inval.replace('1x', 'x')
		if (item.a == 0) inval = inval.replace('0x', '')
		if (item.b == 0) inval = inval.replace('+0', '')
		if (inval == 'y=') {
			input.value = 'y=0'
		} else {
			if (inval[2] == '+') inval = inval.replace('+', '')
			input.value = inval
		}

		input.title = item.name + ' doğrusunu düzenle'
		button.title = item.name + ' doğrusunu sil'
	} else {
		input.value = item.name + "(" + item.xpoint + "," + -item.ypoint + ")"
		input.title = item.name + ' noktasını düzenle'
		button.title = item.name + ' noktasını sil'
	}

	input.setAttribute("onclick", "inputClick(event,id)")
	input.setAttribute("onkeydown", "inputKeyDown(event,id)")
	button.setAttribute("onclick", "delClick(event)")

	label.appendChild(input)
	label.appendChild(button)
	objectsContainer.appendChild(label)
}

function checkRadio(name) {
	switch (name) {
		case 'Siyah':
			activeColor = 'black'
			document.getElementById('point').children[1].style.backgroundImage = "url('img/point_black.svg')"
			document.getElementById('line').children[1].style.backgroundImage = "url('img/line_black.svg')"
			document.getElementById('black').children[1].style.backgroundColor = 'black'
			document.getElementById('blue').children[1].style.backgroundColor = '#dee7ff'
			document.getElementById('red').children[1].style.backgroundColor = '#dee7ff'
			break
		case 'Mavi':
			activeColor = 'blue'
			document.getElementById('point').children[1].style.backgroundImage = "url('img/point_blue.svg')"
			document.getElementById('line').children[1].style.backgroundImage = "url('img/line_blue.svg')"
			document.getElementById('black').children[1].style.backgroundColor = '#dee7ff'
			document.getElementById('blue').children[1].style.backgroundColor = 'blue'
			document.getElementById('red').children[1].style.backgroundColor = '#dee7ff'
			break
		case 'Kırmızı':
			activeColor = 'red'
			document.getElementById('point').children[1].style.backgroundImage = "url('img/point_red.svg')"
			document.getElementById('line').children[1].style.backgroundImage = "url('img/line_red.svg')"
			document.getElementById('black').children[1].style.backgroundColor = '#dee7ff'
			document.getElementById('blue').children[1].style.backgroundColor = '#dee7ff'
			document.getElementById('red').children[1].style.backgroundColor = 'red'
			break
		case 'Seçim':
			activeObject = 'choice'
			canvas.style.cursor = 'pointer'
			break
		case 'Nokta':
			activeObject = 'point'
			canvas.style.cursor = 'crosshair'
			break
		case 'Doğru':
			activeObject = 'line'
			canvas.style.cursor = 'crosshair'
			break
	}
	if (activeElementID != null) {
		arrObjects[activeElementID].color = activeColor
		drawCoordinates()
	}
}

function changeCSS(cssFile) {
	var newlink = document.createElement("link")
	newlink.setAttribute("rel", "stylesheet")
	newlink.setAttribute("type", "text/css")

	if ("css/" + cssFile == "css/styleHorizontal.css") {
		newlink.setAttribute("href", "css/styleVertical.css")
	} else {
		newlink.setAttribute("href", "css/styleHorizontal.css")
	}
	document.getElementsByTagName("head").item(0).children[10].replaceWith(newlink)
}

function inputClick(e, id) {
	if (id == -1) {
		if (activeObject == 'line') {
			document.getElementById(id).value = 'y='
		}
		if (activeObject == 'point') {
			document.getElementById(id).value = '('
		}
	} else {
		if (activeElementID != null) {
			document.getElementById(activeElementID).style.background = 'white'
		}
		activeElementID = id
		document.getElementById(activeElementID).style.background = 'lightgreen'
		document.getElementById(-1).value = null
		let item = arrObjects[id]
		activeColor = item.color

		if (arrObjects[activeElementID].type == 'point') {
			activeObject = 'point'
			document.getElementById('nokta').checked = true
		} else {
			activeObject = 'line'
			document.getElementById('dogru').checked = true
		}

		if (arrObjects[activeElementID].color == 'black') {
			document.getElementById('siyah').checked = true
			document.getElementById('point').children[1].style.backgroundImage = "url('img/point_black.svg')"
			document.getElementById('line').children[1].style.backgroundImage = "url('img/line_black.svg')"

		} else if (arrObjects[activeElementID].color == 'blue') {
			document.getElementById('mavi').checked = true
			document.getElementById('point').children[1].style.backgroundImage = "url('img/point_blue.svg')"
			document.getElementById('line').children[1].style.backgroundImage = "url('img/line_blue.svg')"
		} else {
			document.getElementById('kirmizi').checked = true
			document.getElementById('point').children[1].style.backgroundImage = "url('img/point_red.svg')"
			document.getElementById('line').children[1].style.backgroundImage = "url('img/line_red.svg')"
		}
		setSlider(item)
	}
}

function inputKeyDown(e, id) {
	let keys = ['Backspace', "ArrowLeft", "ArrowRight", "(", ",", ")", "y", "=", "x", "-", "+", "."]
	if (isNaN(e.key) && !keys.includes(e.key)) {
		e.preventDefault()
	}

	let come = document.getElementById(id).value
	if (e.key === 'Enter' && come != '') {
		let vals = isPointLine(come)
		let m = vals.m
		let n = vals.n
		let t = vals.t

		if (m === undefined || n === undefined || t === undefined || isNaN(m) || isNaN(n)) {
			document.getElementById(id).style.background = 'hotpink'
		} else {
			document.getElementById(id).style.background = 'aquamarine'
			canvas.style.cursor = 'crosshair'
			if (t == 'point') {
				document.getElementById('nokta').checked = true
				activeObject = 'point'
				if (id == -1) {
					let point = new mPoint(m, n)
					arrObjects.push(point)
					activeElementID = point.id
					setSlider(point)
					undoObjects = []
					delCount = 0
					objectsContainer.innerHTML = null
				} else {
					activeElementID = id
					arrObjects[id].xpoint = m
					arrObjects[id].ypoint = -n
					arrObjects[id].color = activeColor
					setSlider(arrObjects[id])
				}
			}
			if (t == 'line') {
				document.getElementById('dogru').checked = true
				activeObject = 'line'
				if (id == -1) {
					let line = new mLine(m, n)
					arrObjects.push(line)
					activeElementID = line.id
					undoObjects = []
					delCount = 0
					objectsContainer.innerHTML = null
					setSlider(line)
				} else {
					activeElementID = id
					arrObjects[id].a = m
					arrObjects[id].b = n
					if (Math.sign(n) < 0) {
						arrObjects[id].graph = m + '*x-' + Math.abs(n)
					} else {
						arrObjects[id].graph = m + '*x+' + n
					}
					arrObjects[id].color = activeColor
					setSlider(arrObjects[id])
				}
			}
			drawCoordinates()
		}
	}
}
function isPointLine(come) {
	let m, n, t
	if (come.includes('(') && come.includes(',') && come.includes(')')) {
		if (!isNaN(come.substring(come.indexOf('(') + 1, come.indexOf(',')))) {
			m = Number(come.substring(come.indexOf('(') + 1, come.indexOf(',')))
		}
		if (!isNaN(come.substring(come.indexOf(',') + 1, come.indexOf(')')))) {
			n = Number(come.substring(come.indexOf(',') + 1, come.indexOf(')')))
		}
		t = 'point'
	}

	const re = /(y=)|(=y)/g
	const myArray = come.match(re)
	if (myArray != null & come.includes('y') & come.includes('=') & ((come[0] == 'y' & come[1] == '=') || (come[come.length - 1] == 'y' & come[come.length - 2] == '='))) {
		if (myArray.length == 1) {
			if (come.match(/y/g).length == 1 & come.match(/=/g).length == 1) {
				come = come.replace('y', '')
				come = come.replace('=', '')
				come = come.replaceAll(',', '.')
				if (come != '') {
					const re = /\d*\x\d*/g
					const myArray = come.match(re)

					if (myArray !== null && myArray[0].split('x')[0] != '' && myArray[0].split('x')[1] != '') {
						come = come.replace(myArray[0], myArray[0].split('x')[0] * myArray[0].split('x')[1] + 'x')
					}
					if (isNaN(come[(come.indexOf('x') + 1)])) {
						come = come.replace('-x', '-1x')
						come = come.replace('+x', '+1x')
					}
					if (come.indexOf('x') == 0 & isNaN(come[(come.indexOf('x') + 1)])) come = come.replace('x', '1x')
					if (!isNaN(come)) {
						come >= 0 ? (come = '0x+' + come) : (come = '0x' + come)
						if (come.includes('++')) come = come.replace('++', '+')
					}
					if (!isNaN(come.replace('x', ''))) come = come + '+0'
					if (come.includes('x')) {
						if (come.match(/x/g).length == 1 & !come.includes('+-') & !come.includes('-+') & !come.includes('++') & !come.includes('--')) {
							const nums = (come.replace('x', '')).match(/\+?\-?[0-9.]+/g)
							nums.forEach(n => {
								if (n.includes('+')) nums[nums.indexOf(n)] = (nums[nums.indexOf(n)]).replace('+', '')
							})
							if (come.substring(0, come.indexOf('+', 1)).includes('x') || come.substring(0, come.indexOf('-', 1)).includes('x')) {
								m = nums[0]
								n = nums[1]
							} else {
								n = nums[0]
								m = nums[1]
							}
						}
					}
				}
			}
		}
		t = 'line'
	}
	return { m: m, n: n, t: t }
}

let delCount = 0
function delClick(evt) {
	delCount++
	let idDel = evt.target.parentNode.childNodes[0].id
	if (arrObjects[idDel].type == 'point') delPointCount++
	undoObjects.push(arrObjects.splice(idDel, 1))
	activeElementID = null
	drawCoordinates()
	activeObject = 'choice'
	document.getElementById('secim').checked = true
	canvas.style.cursor = 'pointer'
	document.getElementById('m').innerHTML = 'm'
	document.getElementById('n').innerHTML = 'n'
	document.getElementById('sliderM').disabled = true
	document.getElementById('sliderN').disabled = true
}

//Get mouse position
function getMousePos(canvas, evt) {
	let rect = canvas.getBoundingClientRect()
	let xx, yy

	let intRoundXX = Math.round((evt.clientX - rect.left - _ORIGIN.x) / steppx)
	let fixRoundXX = Number((evt.clientX - rect.left - _ORIGIN.x) / steppx).toFixed(2)

	if (Math.abs(intRoundXX - fixRoundXX) < .1) {
		xx = intRoundXX
	} else {
		xx = fixRoundXX
	}

	let intRoundYY = Math.round((evt.clientY - rect.top - _ORIGIN.y) / -steppy)
	let fixRoundYY = Number((evt.clientY - rect.top - _ORIGIN.y) / -steppy).toFixed(2)
	if (Math.abs(intRoundYY - fixRoundYY) < .1) {
		yy = intRoundYY
	} else {
		yy = fixRoundYY
	}
	return { x: xx, y: yy }
}

function crossSlider(name) {
	let slider = document.getElementById('slider' + name.toUpperCase())
	let sliderLabel = document.getElementById(name)
	if (activeElementID != null) {
		if (arrObjects[activeElementID].type == 'point') {
			if (name == 'm') {
				sliderLabel.innerHTML = 'a = ' + slider.value
				arrObjects[activeElementID].xpoint = slider.value
			} else {
				sliderLabel.innerHTML = 'b = ' + slider.value
				arrObjects[activeElementID].ypoint = -slider.value
			}
		}
		if (arrObjects[activeElementID].type == 'line') {
			if (name == 'm') {
				sliderLabel.innerHTML = 'm = ' + slider.value
				arrObjects[activeElementID].a = slider.value
				arrObjects[activeElementID].b = document.getElementById('sliderN').value
				arrObjects[activeElementID].graph = slider.value + '*x+' + document.getElementById('sliderN').value
			} else {
				sliderLabel.innerHTML = 'n = ' + slider.value
				arrObjects[activeElementID].a = document.getElementById('sliderM').value
				arrObjects[activeElementID].b = slider.value
				arrObjects[activeElementID].graph = document.getElementById('sliderM').value + '*x+' + slider.value
			}
		}
		drawCoordinates()
	}
}

setSlider = function (item) {
	let sliderM = document.getElementById('sliderM')
	let labelM = document.getElementById('m')
	let sliderN = document.getElementById('sliderN')
	let labelN = document.getElementById('n')

	sliderM.disabled = false
	sliderN.disabled = false

	if (item.type == 'point') {
		sliderM.value = item.xpoint
		labelM.innerHTML = 'a = ' + item.xpoint
		sliderM.title = "a sürgüsü"
		sliderN.value = -item.ypoint
		labelN.innerHTML = 'b = ' + -item.ypoint
		sliderN.title = "b sürgüsü"
	}
	if (item.type == 'line') {
		sliderM.value = item.a
		labelM.innerHTML = 'm = ' + item.a
		sliderM.title = "m sürgüsü"
		sliderN.value = item.b
		labelN.innerHTML = 'n = ' + item.b
		sliderN.title = "n sürgüsü"
	}
}

$(document).ready(function () {
	let objectsContainer = document.getElementById('objectsContainer')
	drawCoordinates()
	window.matchMedia("(orientation: portrait)").addEventListener("change", e => {
		changeVariables()
		drawCoordinates()
	})

	window.onresize = function (e) {
		changeVariables()
		drawCoordinates()
	}

	//document.addEventListener('contextmenu', event => event.preventDefault())

	document.getElementById('undo').addEventListener('click', function (e) {
		activeElementID = null
		if (arrObjects.length != 0) {

			if (delCount == 0) {
				undoObjects.push(arrObjects.pop())
			} else {
				arrObjects.push(undoObjects.pop()[0])
				delCount--
			}

			drawCoordinates()
		}
		if (arrObjects.length == 0) {
			activeElementID = null
			activeObject = 'choice'
			document.getElementById('secim').checked = true
			canvas.style.cursor = 'pointer'
			document.getElementById('m').innerHTML = 'a'
			document.getElementById('n').innerHTML = 'b'
			document.getElementById('sliderM').disabled = true
			document.getElementById('sliderN').disabled = true
		}
	}, false)
	document.getElementById('redo').addEventListener('click', function (e) {
		if (undoObjects.length != 0 && delCount == 0) {
			arrObjects.push(undoObjects.pop())
			drawCoordinates()
		}
	}, false)
	document.getElementById('clear').addEventListener('click', function (e) {
		if (arrObjects.length != 0) {
			arrObjects = []
			undoObjects = []
			delCount = 0
			activeColor = 'black'
			activeElementID = null
			document.getElementById('secim').checked = true
			document.getElementById('siyah').checked = true
			document.getElementById('m').innerHTML = 'a'
			document.getElementById('n').innerHTML = 'b'
			document.getElementById('sliderM').disabled = true
			document.getElementById('sliderN').disabled = true
			clearSound.play()
			activeObject = 'choice'
			lineDrawing = false
			canvas.style.cursor = 'pointer'
			changeVariables()
			drawCoordinates()
		}
	}, false)

	document.getElementById('default').addEventListener('click', function (e) {
		sec = 1
		drawCoordinates()
	}, false)

	document.getElementById('plus').addEventListener('click', function (e) {
		if (sec >= 1) {
			sec -= 0.5
			drawCoordinates()
		}
	}, false)

	document.getElementById('minus').addEventListener('click', function (e) {
		sec += 0.5
		drawCoordinates()
	}, false)

	canvas.addEventListener("click", function (evt) {
		if (activeObject === 'point') {
			let mousePos = getMousePos(canvas, evt)
			let point = new mPoint(mousePos.x, mousePos.y)
			setSlider(point)
			arrObjects.push(point)
			activeElementID = point.id
			undoObjects = []
			delCount = 0
			drawCoordinates()
			time = 0
		}
	}, false)

	/*  */
	canvas.addEventListener("dblclick", function (evt) {
		//alert("ÇİFT TIKLAMA")
	}, false)
	/*  */

	canvas.addEventListener("mousemove", function (e) {
		let line
		if (activeObject === 'line') {
			if (lineDrawing == true) {
				lineB = getMousePos(canvas, e)
				if ((lineB.x - lineA.x) != 0) {
					drawCoordinates()
					let m = parseFloat((lineB.y - lineA.y) / (lineB.x - lineA.x)).toFixed(2)
					let c = parseFloat(lineA.y - m * lineA.x).toFixed(2)
					line = new mLine(m, c)

					let x, y
					ctx.strokeStyle = ctx.fillStyle = activeColor
					ctx.beginPath()
					ctx.lineWidth = 3
					x = -lenX * sec
					y = eval(line.graph) * (-stepy / sec) + _ORIGIN.y
					ctx.moveTo(x * stepx / sec + _ORIGIN.x, y)

					x = lenX * sec
					y = eval(line.graph) * (-stepy / sec) + _ORIGIN.y
					ctx.lineTo(x * stepx / sec + _ORIGIN.x, y)
					ctx.stroke()
					ctx.closePath()

					// Draw cutPoints
					ctx.beginPath()
					ctx.strokeStyle = ctx.fill.style = activeColor
					ctx.arc(0 * stepx + _ORIGIN.x, -line.b * stepy + _ORIGIN.y, 6, 0, 2 * Math.PI)
					if (line.b != 0) {
						ctx.arc((-line.b / line.a) * stepx + _ORIGIN.x, 0 * stepy + _ORIGIN.y, 6, 0, 2 * Math.PI)
					}
					ctx.fill()
					ctx.closePath()
				}
			}
		}
	}, false)

	canvas.addEventListener("mousedown", function (e) {
		if (document.getElementById('colapse').style.display != 'block' && activeObject != 'choice') {
			document.getElementById('leftWrapper').classList.toggle('hide')
			document.getElementById('colapse').style.display = 'block'
		}

		if (activeObject === 'line' && e.button == 0) {
			if (lineDrawing == false) {
				lineA = getMousePos(canvas, e)
				let point = new mPoint(lineA.x, lineA.y)
				arrObjects.push(point)
				undoObjects = []
				delCount = 0
				lineDrawing = true
			} else {
				lineB = getMousePos(canvas, e)
				let point = new mPoint(lineB.x, lineB.y)
				arrObjects.push(point)
				undoObjects = []
				delCount = 0
				lineDrawing = false
			}
			if (lineA != null && lineB != null) {
				createEquation(lineA, lineB)
				lineA = lineB = null
				time = 0
			}
			drawCoordinates()
		}
	}, false)

	document.addEventListener("keydown", function (evt) {
		if (evt.key == 'Escape') {
			if (lineDrawing == true) {
				lineDrawing = false
				lineA = lineB = null
				arrObjects.pop()
			}
			drawCoordinates()
			time = 0
		}
	}, false)

	function createEquation(lineA, lineB) {
		if ((lineB.x - lineA.x) != 0) {
			let m = (lineB.y - lineA.y) / (lineB.x - lineA.x)
			let c = lineA.y - m * lineA.x

			if (!Number.isInteger(m)) {
				m = Number((lineB.y - lineA.y) / (lineB.x - lineA.x)).toFixed(2)
			}
			if (!Number.isInteger(c)) {
				c = Number(lineA.y - m * lineA.x).toFixed(2)
			}

			let line = new mLine(m, c)
			setSlider(line)
			arrObjects.push(line)
			activeElementID = line.id
			objectsContainer.innerHTML = null
			drawCoordinates()
		}
	}

	document.getElementById('colapse').addEventListener("click", function (evt) {
		document.getElementById('leftWrapper').classList.toggle('hide')
		document.getElementById('colapse').style.display = 'none'
	}, false)

	myTime = setInterval(setSecond, 1000)
	function setSecond() {
		time++
		if (time == 5 && document.getElementById('colapse').style.display == 'block' && lineDrawing == false) {
			document.getElementById('leftWrapper').classList.toggle('hide')
			document.getElementById('colapse').style.display = 'none'
		}
	}
})